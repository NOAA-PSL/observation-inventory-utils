from .obs_inv_cli import cli
