# 2024-04-16
# obs_inv_queries.py
# Seth Cohen
# Discover additions

from datetime import datetime

from pandas import DataFrame
import sqlalchemy as db
from sqlalchemy import Table, Column, MetaData
from sqlalchemy import Integer, String, Boolean, DateTime, Float
from sqlalchemy import inspect
from sqlalchemy import func, select, column
from sqlalchemy import and_, or_, not_
from sqlalchemy.orm import relationship, backref
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker


from obs_inv_utils import inventory_table_factory as itf
from obs_inv_utils import obs_storage_platforms as platforms

engine = db.create_engine(itf.OBS_DATABASE, echo=True)
Base = declarative_base()
Session = sessionmaker(bind=engine)


def get_family_fs_data(obs_family):
    insp = inspect(engine)
    table_exists = insp.has_table(itf.OBS_INVENTORY_TABLE)

    if not table_exists:
        msg = f'Table \'{itf.OBS_INVENTORY_TABLE}\' does not ' \
              f'exist in database: \'{itf.OBS_DATABASE}\'.'
        raise ValueError(msg)

    session = Session()
    oi = itf.ObsInventory
    print(
        f'Here in sql query - table_exists: {table_exists}, obs_family: {obs_family}')
    filenames = set()
    members = obs_family.get_members()
    #print(f'------------------- print(oi) --------- \ {oi}')
    #print(f'------------------- print(obs_family) ----------- \ {print(obs_family)} ')
    #print(f'------------------- print(members) ----------- \ {print(members)}')
    for member in members:
        filename = member.get('prefix') + '.%.' + member.get('cycle_tag') + member.get('data_type') + member.get('suffix')
        filenames.add(filename)

    print(f'filenames: {filenames}')

    fn_fs = session.query(
        oi.prefix,
        oi.filename,
        oi.cycle_tag,
        oi.cycle_time,
        oi.data_type,
        oi.file_size,
        oi.obs_day,
        oi.inserted_at,
        oi.suffix,
        oi.platform,
        oi.parent_dir.concat(oi.filename).label('full_path'),
        func.max(oi.inserted_at).label('latest_record')
    ).select_from(
        oi
    ).filter(
        and_(
            #oi.platform.like('%discover%'),
            oi.platform != None,
            #or_(
            #    oi.platform.like('%aws_s3%')
            #),
            or_(
                oi.filename.like(fn) for fn in filenames
            )
        )
    ).group_by(
        'full_path'
        # ).order_by(
        #     oi.filename, oi.obs_day, oi.cycle_time, oi.inserted_at
    ).all()

    df = DataFrame(fn_fs)
    return df


def get_filesize_timeline_data(min_instances):

    insp = inspect(engine)
    table_exists = insp.has_table(itf.OBS_INVENTORY_TABLE)

    if not table_exists:
        msg = f'Table \'{itf.OBS_INVENTORY_TABLE}\' does not ' \
              f'exist in database: \'{itf.OBS_DATABASE}\'.'
        raise ValueError(msg)

    session = Session()
    oi = itf.ObsInventory

    unique_names = session.query(
        oi.filename,
        func.count(oi.filename).label('instances'),
        oi.data_type,
        oi.suffix,
        #oi.platform,
        oi.data_type.concat(oi.suffix).label('un')
    ).select_from(
        oi
    ).group_by(
        'un'
    ).subquery()

    print(f'subquery unique_names: {unique_names}')

    fn_fs = session.query(
        oi.prefix,
        oi.filename,
        oi.cycle_tag,
        oi.cycle_time,
        oi.data_type,
        oi.file_size,
        oi.obs_day,
        oi.inserted_at,
        oi.platform,
        unique_names.c.instances,
        unique_names.c.un
    ).select_from(
        oi
    ).join(
        unique_names,
        and_(
            unique_names.c.data_type == oi.data_type,
            unique_names.c.suffix == oi.suffix
        )
    ).filter(
        and_(
            unique_names.c.instances > min_instances,
            oi.prefix != '',
            oi.cycle_time != None,
            not_(
                or_(
                    oi.filename.contains('.txt'),
                    oi.filename.contains('./'),
                    oi.filename.contains('.nr.nr'),
                    oi.filename.contains('/tmp')
                )
            )
        )
    ).order_by(
        unique_names.c.instances, oi.filename, oi.obs_day
    ).all()

    df = DataFrame(fn_fs)

    return df


def get_bufr_files_data(filenames, start, end):

    insp = inspect(engine)
    table_exists = insp.has_table(itf.OBS_INVENTORY_TABLE)

    if not table_exists:
        msg = f'Table \'{itf.OBS_INVENTORY_TABLE}\' does not ' \
              f'exist in database: \'{itf.OBS_DATABASE}\'.'
        raise ValueError(msg)

    session = Session()
    oi = itf.ObsInventory

    print(
        f'Here in sql query - bufr_filenames: {filenames}, {start}, {end}')
    unique_filenames = set()
    for filename in filenames:
        unique_filenames.add(filename)


    unique_platforms = set()
    unique_platforms.add('discover')
    unique_platforms.add('aws_s3')
    print(f'unique_platforms: {unique_platforms}')
 
    fn_fs = session.query(
        oi.obs_id,
        oi.prefix.label('prefix'),
        oi.filename,
        oi.cycle_tag,
        oi.cycle_time,
        oi.data_type,
        oi.file_size,
        oi.obs_day,
        oi.inserted_at,
        oi.suffix,
        oi.platform,
        oi.parent_dir.concat(oi.filename).label('full_path'),
        func.max(oi.inserted_at).label('latest_record')
    ).select_from(
        oi
    ).filter(
        and_(
            #oi.platform == 'discover',
            #oi.platform == 'aws_s3',
            #oi.platform.like('%discover%'),
            #oi.platform.like('%aws_s3%'),
            oi.platform != None,
            #oi.platform.like(p) for p in unique_platforms,
            #or_(
                #oi.platform.like('%aws_s3%')
            #    oi.platform.like(p) for p in unique_platforms
            #),
            or_(
                oi.filename.like(fn) for fn in unique_filenames
            ),
            oi.obs_day >= start,
            oi.obs_day <= end
        )
    ).group_by(
        'full_path'
        # ).order_by(
        #     oi.filename, oi.obs_day, oi.cycle_time, oi.inserted_at
    ).order_by(
        oi.obs_day,
        oi.filename
    ).all()
    
    print(f'type(fn_fs): {type(fn_fs)}')
    print(f'fn_fs: {fn_fs}')

    #df = DataFrame(fn_fs, columns= ['obs_id', 'prefix', 'filename', 'cycle_tag', 'cycle_time', 'data_type', 'file_size', 'obs_day', 'inserted_at', 'suffix', 'full_path', 'latest_record'])
    #print(f'df: {df}')
    df = DataFrame(fn_fs)
    print(f'df: {df}')
    return df
